// Phase 1 stub: remote policy source.

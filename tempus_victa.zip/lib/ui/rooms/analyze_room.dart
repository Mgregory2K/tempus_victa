import 'package:flutter/material.dart';

import '../room_frame.dart';
import '../theme/tempus_theme.dart';
import '../theme/tempus_ui.dart';      // gives you TempusCard
import '../theme/tempus_widgets.dart';

class AnalyzeRoom extends StatelessWidget {
  final String roomName;

  const AnalyzeRoom({super.key, required this.roomName});

  @override
  Widget build(BuildContext context) {
    final b = context.tv;

    return RoomFrame(
      title: roomName,
      // RoomFrame in your project doesn't consistently support subtitle everywhere; keep body-only.
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TempusCard(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.psychology),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Analyze',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                    ),
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: b.accent,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: LayoutBuilder(
                builder: (ctx, c) {
                  final size = c.biggest;
                  final center = Offset(size.width / 2, size.height / 2);
                  final hubSize = 130.0;

                  Widget hub() => Center(
                        child: TempusCard(
                          child: SizedBox(
                            width: hubSize,
                            height: hubSize,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.memory, size: 40),
                                SizedBox(height: 8),
                                Text('AI', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                                SizedBox(height: 4),
                                Text('Learning', style: TextStyle(fontWeight: FontWeight.w700)),
                              ],
                            ),
                          ),
                        ),
                      );

                  Widget spoke(String title, IconData icon) => TempusCard(
                        onTap: () => _openDetail(ctx, title),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Icon(icon),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  title,
                                  style: const TextStyle(fontWeight: FontWeight.w800),
                                ),
                              ),
                              const Icon(Icons.chevron_right),
                            ],
                          ),
                        ),
                      );

                  // simple, deterministic positions around the hub (no fancy constraints yet)
                  final pad = 12.0
                  ;
                  final cardW = (size.width - pad * 2);
                  // In small screens keep as a vertical list around hub
                  if (size.width < 420) {
                    return Column(
                      children: [
                        Expanded(child: hub()),
                        const SizedBox(height: 12),
                        spoke('Signals → Patterns', Icons.notifications_active),
                        const SizedBox(height: 10),
                        spoke('What You Ignore', Icons.visibility_off),
                        const SizedBox(height: 10),
                        spoke('What You Promote', Icons.trending_up),
                        const SizedBox(height: 10),
                        spoke('Time Unlocked', Icons.timer),
                      ],
                    );
                  }

                  // Wider: hub + surrounding cards
                  return Stack(
                    children: [
                      Positioned.fill(child: hub()),
                      Positioned(
                        left: 0,
                        top: 0,
                        right: 0,
                        child: SizedBox(width: cardW, child: spoke('Signals → Patterns', Icons.notifications_active)),
                      ),
                      Positioned(
                        left: 0,
                        bottom: 0,
                        right: 0,
                        child: SizedBox(width: cardW, child: spoke('Time Unlocked', Icons.timer)),
                      ),
                      Positioned(
                        left: 0,
                        top: center.dy - 42,
                        child: SizedBox(width: (size.width / 2) - (hubSize / 2) - 10, child: spoke('What You Ignore', Icons.visibility_off)),
                      ),
                      Positioned(
                        right: 0,
                        top: center.dy - 42,
                        child: SizedBox(width: (size.width / 2) - (hubSize / 2) - 10, child: spoke('What You Promote', Icons.trending_up)),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openDetail(BuildContext context, String title) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              const Text(
                'This board will show what the system is learning about you (local-first). '
                'Tap tiles to drill down. Sorting/automation comes after patterns are reliable.',
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Close'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

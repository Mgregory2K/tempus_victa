// Tempus Victa rebuild - updated 2026-02-21
// Local-first, Android-first.

import 'package:flutter/material.dart';
import 'package:mobile/ui/tempus_nav.dart';

class TempusCarouselNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onTap;
  final List<TempusNavItem> items;

  const TempusCarouselNav({
    super.key,
    required this.selectedIndex,
    required this.onTap,
    this.items = tempusNavItems,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final bottomPad = MediaQuery.of(context).viewPadding.bottom;

    return Material(
      elevation: 10,
      color: cs.surface,
      child: Container(
        padding: EdgeInsets.only(bottom: bottomPad),
        child: SizedBox(
          height: 76,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final item = items[i];
              final selected = i == selectedIndex;

              return InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => onTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  curve: Curves.easeOut,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? cs.primaryContainer : cs.surfaceContainerHighest.withOpacity(0.55),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: selected ? cs.primary.withOpacity(0.35) : cs.outlineVariant.withOpacity(0.25),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.icon, size: 20, color: selected ? cs.onPrimaryContainer : cs.onSurface),
                      const SizedBox(width: 10),
                      Text(
                        item.label,
                        style: TextStyle(
                          fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                          color: selected ? cs.onPrimaryContainer : cs.onSurface,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

// Tempus Victa - Root Shell
//
// IMPORTANT: Nav bar does NOT live in RootShell by design.
// RootShell only swaps pages; each page renders its own persistent nav (SafeArea aware).

import 'package:flutter/material.dart';

import '../features/actions/actions_screen.dart';
import '../features/bridge/bridge_screen.dart';
import '../features/corkboard/corkboard_screen.dart';
import '../features/projects/projects_screen.dart';
import '../features/recycle/recycle_screen.dart';
import '../features/ready_room/ready_room_screen.dart';
import '../features/signals/signals_screen.dart';
import '../features/settings/settings_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _selectedIndex = 0;

  void _setIndex(int i) => setState(() => _selectedIndex = i);

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      BridgeScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      SignalsScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      ActionsScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      ProjectsScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      CorkboardScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      RecycleScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      ReadyRoomScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
      SettingsScreen(onNavigate: _setIndex, selectedIndex: _selectedIndex),
    ];

    final idx = _selectedIndex.clamp(0, pages.length - 1);
    return pages[idx];
  }
}

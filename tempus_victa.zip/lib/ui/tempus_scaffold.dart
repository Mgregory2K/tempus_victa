// Tempus Victa rebuild - updated 2026-02-21
// Local-first, Android-first.

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:mobile/ui/widgets/tempus_background.dart';
import 'package:mobile/ui/widgets/tempus_carousel_nav.dart';

class TempusScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final int selectedIndex;
  final ValueChanged<int> onNavigate;
  final List<Widget>? actions;

  const TempusScaffold({
    super.key,
    required this.title,
    required this.body,
    required this.selectedIndex,
    required this.onNavigate,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    // Ensures bottom nav never hides behind Android gesture/nav bars.
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: actions,
      ),
      body: TempusBackground(
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: body,
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: math.max(8, MediaQuery.of(context).viewPadding.bottom)),
          child: TempusCarouselNav(
            selectedIndex: selectedIndex,
            onTap: onNavigate,
          ),
        ),
      ),
    );
  }
}
// Tempus Victa - navigation model

import 'package:flutter/material.dart';

class TempusNavItem {
  final String key;
  final String label;
  final IconData icon;

  const TempusNavItem({
    required this.key,
    required this.label,
    required this.icon,
  });
}

const tempusNavItems = <TempusNavItem>[
  TempusNavItem(key: 'bridge', label: 'Bridge', icon: Icons.home),
  TempusNavItem(key: 'signals', label: 'Signal Bay', icon: Icons.inbox),
  TempusNavItem(key: 'tasks', label: 'Actions', icon: Icons.check_circle),
  TempusNavItem(key: 'projects', label: 'Projects', icon: Icons.view_kanban),
  TempusNavItem(key: 'corkboard', label: 'Corkboard', icon: Icons.push_pin),
  TempusNavItem(key: 'recycle', label: 'Recycle', icon: Icons.delete_outline),
  TempusNavItem(key: 'ready_room', label: 'Ready Room', icon: Icons.forum),
  TempusNavItem(key: 'settings', label: 'Settings', icon: Icons.settings),
];

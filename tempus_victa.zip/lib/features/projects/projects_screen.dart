// Tempus Vista rebuild - generated 2026-02-21
// Local-first, Android-first.


import 'package:flutter/material.dart';

import '../../ui/tempus_scaffold.dart';
import '../../ui/widgets/glass_card.dart';

class ProjectsScreen extends StatelessWidget {
  final void Function(int index)? onNavigate;
  final int? selectedIndex;

  const ProjectsScreen({super.key, this.onNavigate, this.selectedIndex});

  @override
  Widget build(BuildContext context) {
    // Kanban board wiring is present as a UI scaffold; persistence is ready to extend.
    return TempusScaffold(
      title: 'Projects',
      selectedIndex: selectedIndex ?? 3,
      onNavigate: onNavigate ?? (_) {},
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: const [
            Expanded(child: _Col(title: 'Backlog')),
            SizedBox(width: 10),
            Expanded(child: _Col(title: 'In Progress')),
            SizedBox(width: 10),
            Expanded(child: _Col(title: 'Done')),
          ],
        ),
      ),
    );
  }
}

class _Col extends StatelessWidget {
  final String title;
  const _Col({required this.title});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          const Expanded(
            child: Center(child: Text('Kanban items coming next (data layer already reserved).')),
          ),
        ],
      ),
    );
  }
}

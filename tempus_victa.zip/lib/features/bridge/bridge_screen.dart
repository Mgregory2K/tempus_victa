// Tempus Victa rebuild - generated 2026-02-21
// Local-first, Android-first.


import 'package:flutter/material.dart';

import '../../data/repositories/signal_repo.dart';
import '../../data/repositories/task_repo.dart';
import '../../services/learning/learning_engine.dart';
import '../../services/ai/ai_key.dart';
import '../../services/ai/openai_client.dart';
import '../../services/logging/jsonl_logger.dart';
import '../../services/routing/command_router.dart';
import '../../services/voice/voice_service.dart';
import '../../ui/tempus_scaffold.dart';
import '../../ui/widgets/glass_card.dart';
import '../../widgets/input_composer.dart';

class BridgeScreen extends StatefulWidget {
  final void Function(int index) onNavigate;
  final int selectedIndex;

  const BridgeScreen({
    super.key,
    required this.onNavigate,
    required this.selectedIndex,
  });

  @override
  State<BridgeScreen> createState() => _BridgeScreenState();
}

class _BridgeScreenState extends State<BridgeScreen> {
  static const String source = 'bridge';
  bool _listening = false;
  String _partial = '';

  Future<void> _ingestText({String? text, String? transcript}) async {
    final nowUtc = DateTime.now().toUtc();
    if (text != null) {
      final s = await SignalRepo.instance.create(
        kind: 'text',
        source: 'bridge_text',
        text: text,
        capturedAtUtc: nowUtc,
      );
      await JsonlLogger.instance.append('signals.jsonl', {
        'event': 'signal_ingested',
        'id': s.id,
        'kind': 'text',
        'source': 'bridge_text',
        'capturedAtUtc': nowUtc.toIso8601String(),
        'text': text,
      });

      // Always create an inbox/open task so nothing is lost.
      await TaskRepo.instance.create(
        title: text,
        details: null,
        source: 'bridge_text',
        signalId: s.id,
        capturedAtUtc: nowUtc,
      );
      await LearningEngine.instance.bumpRoute(fromSource: 'bridge_text', toBucket: 'inbox');
    }

    if (transcript != null) {
      final s = await SignalRepo.instance.create(
        kind: 'voice',
        source: 'bridge_voice',
        transcript: transcript,
        capturedAtUtc: nowUtc,
      );

      await JsonlLogger.instance.append('signals.jsonl', {
        'event': 'signal_ingested',
        'id': s.id,
        'kind': 'voice',
        'source': 'bridge_voice',
        'capturedAtUtc': nowUtc.toIso8601String(),
        'transcript': transcript,
      });

      final route = CommandRouter.route(transcript);
      var kind = route.kind;
      // If deterministic route can't classify, let AI take a swing (optional).
      if (kind == 'unknown') {
        final apiKey = (await AiKey.get())?.trim();
        if (apiKey != null && apiKey.isNotEmpty) {
          final aiKind = await OpenAiClient.assistLabel(apiKey: apiKey, input: transcript);
          if (aiKind != null && aiKind != 'unknown') {
            kind = aiKind;
          }
        }
      }
      // Minimal deterministic routing: always create a task if unsure.
      final title = (route.payload.isEmpty) ? transcript : route.payload;
      await TaskRepo.instance.create(
        title: kind == 'unknown' ? 'Follow up: $title' : title,
        details: 'From voice: "$transcript"',
        source: 'bridge_voice',
        signalId: s.id,
        capturedAtUtc: nowUtc,
      );

      await LearningEngine.instance.bumpRoute(fromSource: 'bridge_voice', toBucket: 'inbox');
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Captured ✅')),
    );
  }

  Future<void> _toggleAdhdMic() async {
    if (_listening) {
      final finalText = await VoiceService.instance.stopAndGetFinal();
      setState(() {
        _listening = false;
        _partial = '';
      });
      if (finalText.trim().isNotEmpty) {
        await _ingestText(transcript: finalText);
      }
      return;
    }

    setState(() {
      _listening = true;
      _partial = '';
    });

    await VoiceService.instance.startListening(
      listenFor: const Duration(minutes: 5),
      onPartial: (w) {
        if (!mounted) return;
        setState(() => _partial = w);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return TempusScaffold(
      title: 'Bridge',
      actions: [
        IconButton(
          tooltip: 'AI Key',
          icon: const Icon(Icons.key),
          onPressed: () async {
            final controller = TextEditingController(text: (await AiKey.get()) ?? '');
            if (!context.mounted) return;
            final saved = await showDialog<bool>(
              context: context,
              builder: (ctx) {
                return AlertDialog(
                  title: const Text('OpenAI API Key'),
                  content: TextField(
                    controller: controller,
                    decoration: const InputDecoration(hintText: 'sk-...'),
                    obscureText: true,
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(
                      onPressed: () async {
                        final v = controller.text.trim();
                        if (v.isEmpty) {
                          await AiKey.clear();
                        } else {
                          await AiKey.set(v);
                        }
                        if (ctx.mounted) Navigator.pop(ctx, true);
                      },
                      child: const Text('Save'),
                    ),
                  ],
                );
              },
            );
            if (saved == true && context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI key saved')));
            }
          },
        )
      ],
      selectedIndex: widget.selectedIndex,
      onNavigate: widget.onNavigate,
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'ADHD Dump (1‑button capture)',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: _toggleAdhdMic,
                    icon: Icon(_listening ? Icons.stop_circle : Icons.mic),
                    label: Text(_listening ? 'Stop & Capture' : 'Press to Record'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (_listening)
                    Text(
                      _partial.isEmpty ? 'Listening…' : _partial,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              child: InputComposer(
                hint: 'Type an idea / task / note…',
                onSubmit: ({text, transcript}) => _ingestText(text: text, transcript: transcript),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Next steps', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    const Text('• Anything you capture becomes a Signal and also a Task immediately.'),
                    const Text('• Go to Signal Bay to route/clean.'),
                    const Text('• Go to Actions to complete tasks.'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

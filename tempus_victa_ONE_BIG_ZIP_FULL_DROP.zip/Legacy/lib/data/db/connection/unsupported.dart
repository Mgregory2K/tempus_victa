import 'package:drift/drift.dart';

DatabaseConnection connect() {
  throw 'Platform not supported';
}

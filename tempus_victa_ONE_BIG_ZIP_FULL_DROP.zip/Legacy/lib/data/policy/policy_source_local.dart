// Phase 1 stub: local policy source.
